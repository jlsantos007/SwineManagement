<!DOCTYPE html>
<html>
<head>
	<title>Practice 4</title>
</head>
<body>	
	<form action="factorial.php" method="post">
		<input type="text"   name="numFactorial">
		<input type="submit" value="Calculate">
	</form>
</body>
</html>